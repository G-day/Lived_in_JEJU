package com.example.afinal.Features.UpdateStudentInfo;
import com.example.afinal.Features.CreateStudent.Student;

public interface StudentUpdateListener {
    void onStudentInfoUpdated(Student student, int position);
}
