package com.example.afinal;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MypageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mypage);
    }

    public void changeMemInfo(View v){
        startToast("회원정보를 수정합니다.");
        Intent intent = new Intent(getApplicationContext(), MemberInitActivity.class);
        // 회원정보 화면으로 이동
        startActivity(intent);

    }

    public void memOut(View v){
        AlertDialog.Builder builder=new AlertDialog.Builder(MypageActivity.this);
        builder.setTitle("탈퇴하시겠습니까?");
        builder.setMessage("회원 정보가 삭제되며 해당 계정으로 로그인이 불가능합니다.");
        builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getBaseContext(), "탈퇴가 완료되었습니다.", Toast.LENGTH_SHORT).show();

            }
        });
        builder.setNeutralButton("취소", null);
        builder.create().show();
    }
    private void startToast(String msg) {   // 토스트 문장 출력
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void myStartActivity(Class c) {
        Intent intent = new Intent(this, c);
        startActivity(intent);
    }
}


