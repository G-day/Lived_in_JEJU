package com.example.afinal.Features.CreateStudent;

public interface StudentCreateListener {
    void onStudentCreated(Student student);
}
